import {StatusFlagBuilder} from './StatusFlagBuilder';

describe('StatusFlagBuilder', () => {
  it('should create an instance', () => {
    expect(new StatusFlagBuilder()).toBeTruthy();
  });
});
