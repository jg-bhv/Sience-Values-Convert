export class StatusFlagBuilder {
  public status: boolean = false;
  public NameTrue: string = 'true';
  public NameFalse: string = 'false';
  public STATUS: string;


  constructor(NameTrue?: string, NameFalse?: string, status: boolean = false) {
    this.NameTrue = NameTrue;
    this.NameFalse = NameFalse;

    this.status = status;

    if (this.status === true) {
      this.STATUS = this.NameTrue;
    } else {
      this.STATUS = this.NameFalse;
    }
  }


}
