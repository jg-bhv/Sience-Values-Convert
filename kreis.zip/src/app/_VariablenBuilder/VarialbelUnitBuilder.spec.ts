import {TestBed} from '@angular/core/testing';

import {VariableUnitBuilder} from './variableUnitBuilder';

describe('VariablenBiegebalkenService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VariableUnitBuilder = TestBed.get(VariableUnitBuilder);
    expect(service).toBeTruthy();
  });
});
