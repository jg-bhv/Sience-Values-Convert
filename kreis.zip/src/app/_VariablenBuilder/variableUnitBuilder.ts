export class VariableUnitBuilder {

  public unit = '0';
  public inputStr = '0';
  public inputValue = 0;
  public nominalValue = 0;
  public scaleSelect = 1;
  public showStr = '0';
  public showValue = 0;
  public nominalValueOld = 0;
  public unitSI = '0';

  constructor(unit: string, inputStr?: string) {
    this.unit = unit;
    this.unitSI = unit;

    if (inputStr) {
      this.inputStr = inputStr.toString();
      this.inputValue = parseFloat(inputStr);
      this.nominalValue = parseFloat(inputStr);
      this.showValue = parseFloat(inputStr);
    }
  }
}
