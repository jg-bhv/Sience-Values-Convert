import {Component, OnInit} from '@angular/core';
import {VariableUnitBuilder} from '../../../_VariablenBuilder/variableUnitBuilder';
import {StatusFlagBuilder} from '../../../_VariablenBuilder/StatusFlagBuilder';
import {UnitConverterService} from '../../../_VariablenBuilder/unit-converter.service';

@Component({
  selector: 'jg-kreis',
  templateUrl: './kreis.component.html',
  styleUrls: ['./kreis.component.sass']
})
export class KreisComponent implements OnInit {


  public D = new VariableUnitBuilder('mm',);
  public d = new VariableUnitBuilder('mm',);
  public s = new VariableUnitBuilder('mm',);
  public Area = new VariableUnitBuilder('mm²');
  public W = new VariableUnitBuilder('mm³');
  public I = new VariableUnitBuilder('mm⁴');

  public fixD = new StatusFlagBuilder('fix', 'var', false);
  public fixd = new StatusFlagBuilder('fix', 'var', false);
  public fixs = new StatusFlagBuilder('fix', 'var', false);

  public visible: boolean;
  public visibleCalc: boolean;


  constructor(private UnitConvert: UnitConverterService) {
    this.fixd.status = true;
    this.fixd.STATUS = this.fixd.NameTrue;

  }

  ngOnInit(): void {
  }

  validate(obj: VariableUnitBuilder): void {
    obj.inputValue = parseFloat(obj.inputStr.replace(/,/, '.'));
    obj.nominalValue = obj.inputValue * obj.scaleSelect;
    obj.showValue = obj.nominalValue / obj.scaleSelect;
  }

  unitSwitch(obj: VariableUnitBuilder): void {
    this.UnitConvert.unitSwitch(obj);
  }


  keyup_D(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixs.status == true) {
      this.d_Ds();
    }

    this.s_Dd();
    this.foo_AreaWI();
  }

  keyup_s(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixD.status == true) {
      this.d_Ds();
    } else {
      this.D_ds();
    }

    this.foo_AreaWI();
  }


  keyup_d(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixD.status == true) {
      this.s_Dd();
    } else {
      this.D_ds();
    }

    this.foo_AreaWI();
  }


  fix_change(obj: StatusFlagBuilder) {
    obj.status = !obj.status;  // ACTION

    // Bedingungen der Möglichkeiten


    if (obj != this.fixD) {
      this.fixD.status = false;
      this.fixD.STATUS = this.fixD.NameFalse;
    }
    if (obj != this.fixd) {
      this.fixd.status = false;
      this.fixd.STATUS = this.fixd.NameFalse;
    }
    if (obj != this.fixs) {
      this.fixs.status = false;
      this.fixs.STATUS = this.fixs.NameFalse;
    }

//##########NAMENSUMASCHLAD AM ENDE###############
    if (obj.status === true) {
      obj.STATUS = obj.NameTrue;
    } else {
      obj.STATUS = obj.NameFalse;
    }
  }


// SINGLE FUNCTIONS

  s_Dd(): void {

    const D = this.D.nominalValue;
    const d = this.d.nominalValue;

    let s = (D - d) / 2;
    this.s.nominalValue = s;
    this.UnitConvert.showValueResult(this.s);
  }

  d_Ds(): void {

    const D = this.D.nominalValue;
    const s = this.s.nominalValue;

    let d = D - 2 * s;
    this.d.nominalValue = d;
    this.UnitConvert.showValueResult(this.d);
  }

  D_ds(): void {

    const d = this.d.nominalValue;
    const s = this.s.nominalValue;

    let D = d + 2 * s;
    this.D.nominalValue = D;
    this.UnitConvert.showValueResult(this.D);
  }

  Area_Dd(): void {

    const D = this.D.nominalValue;
    const d = this.d.nominalValue;
    let Area: number;

    Area = (Math.PI / 4) * (Math.pow(D, 2) - Math.pow(d, 2));
    this.Area.nominalValue = Area;
    this.UnitConvert.showValueResult(this.Area);
  }

  W_Dd(): void {

    const D = this.D.nominalValue;
    const d = this.d.nominalValue;

    let W = (Math.PI / 32) * ((Math.pow(D, 4) - Math.pow(d, 4)) / D);
    this.W.nominalValue = W;
    this.UnitConvert.showValueResult(this.W);
  }

  I_Dd(): void {

    const D = this.D.nominalValue;
    const d = this.d.nominalValue;

    let I = (Math.PI / 64) * ((Math.pow(D, 4) - Math.pow(d, 4)));
    this.I.nominalValue = I;
    this.UnitConvert.showValueResult(this.I);
  }


// COLLECTION FUNCTIONS


  foo_AreaWI(): void {
    this.Area_Dd();
    this.W_Dd();
    this.I_Dd();
  }


}
