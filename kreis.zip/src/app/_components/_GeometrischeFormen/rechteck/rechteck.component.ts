import {Component, OnInit} from '@angular/core';
import {VariableUnitBuilder} from '../../../_VariablenBuilder/variableUnitBuilder';
import {UnitConverterService} from '../../../_VariablenBuilder/unit-converter.service';
import {StatusFlagBuilder} from '../../../_VariablenBuilder/StatusFlagBuilder';


@Component({
  selector: 'jg-rechteck',
  templateUrl: './rechteck.component.html',
  styleUrls: ['./rechteck.component.sass']
})
export class RechteckComponent implements OnInit {

  public H = new VariableUnitBuilder('mm',);
  public B = new VariableUnitBuilder('mm',);
  public h = new VariableUnitBuilder('mm',);
  public b = new VariableUnitBuilder('mm',);
  public s_H = new VariableUnitBuilder('mm',);
  public s_B = new VariableUnitBuilder('mm');
  public Area = new VariableUnitBuilder('mm²');
  public W = new VariableUnitBuilder('mm³');
  public I = new VariableUnitBuilder('mm⁴');

  public fixH = new StatusFlagBuilder('fix', 'var', false);
  public fixs_H = new StatusFlagBuilder('fix', 'var', false);
  public fixh = new StatusFlagBuilder('fix', 'var', false);
  public fixB = new StatusFlagBuilder('fix', 'var', false);
  public fixs_B = new StatusFlagBuilder('fix', 'var', false);
  public fixb = new StatusFlagBuilder('fix', 'var', false);

  public visible: boolean;
  public visibleCalc: boolean;

  constructor(private UnitConvert: UnitConverterService) {
    this.fixh.status = true;
    this.fixh.STATUS = this.fixh.NameTrue;
    this.fixb.status = true;
    this.fixb.STATUS = this.fixb.NameTrue;
  }

  ngOnInit(): void {
  }

  validate(obj: VariableUnitBuilder): void {
    obj.inputValue = parseFloat(obj.inputStr.replace(/,/, '.'));
    obj.nominalValue = obj.inputValue * obj.scaleSelect;
    obj.showValue = obj.nominalValue / obj.scaleSelect;
  }

  unitSwitch(obj: VariableUnitBuilder): void {
    this.UnitConvert.unitSwitch(obj);
  }

  //-----------HOEHE----------------
  keyup_H(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixs_H.status == true) {
      this.h_Hs();
    }

    this.s_Hh();
    this.foo_AreaWI();
  }

  keyup_s_H(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixH.status == true) {
      this.h_Hs();
    } else {
      this.H_hs();
    }

    this.foo_AreaWI();
  }

  keyup_h(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixH.status == true) {
      this.s_Hh();
    } else {
      this.H_hs();
    }

    this.foo_AreaWI();
  }

//+++++++++++

  h_Hs() {
    let objResult = this.h;
    const H = this.H.nominalValue;
    const s_H = this.s_H.nominalValue;

    objResult.nominalValue = H - 2 * s_H;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }

  s_Hh() {
    let objResult = this.s_H;
    const H = this.H.nominalValue;
    const h = this.h.nominalValue;

    objResult.nominalValue = (H - h) / 2;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }

  H_hs() {
    let objResult = this.H;
    const h = this.h.nominalValue;
    const s_H = this.s_H.nominalValue;

    objResult.nominalValue = h + 2 * s_H;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }

//-----------BREITE----------------
  keyup_B(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixs_B.status == true) {
      this.b_Bs();
    }

    this.s_Bb();
    this.foo_AreaWI();
  }

  keyup_s_B(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixB.status == true) {
      this.b_Bs();
    } else {
      this.B_bs();
    }

    this.foo_AreaWI();
  }

  keyup_b(obj: VariableUnitBuilder): void {
    this.validate(obj);

    if (this.fixH.status == true) {
      this.s_Bb();
    } else {
      this.B_bs();
    }

    this.foo_AreaWI();
  }


  b_Bs() {
    let objResult = this.b;
    const B = this.B.nominalValue;
    const s_B = this.s_B.nominalValue;

    objResult.nominalValue = B - 2 * s_B;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }

  s_Bb() {
    let objResult = this.s_B;
    const B = this.B.nominalValue;
    const b = this.b.nominalValue;

    objResult.nominalValue = (B - b) / 2;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }

  B_bs() {
    let objResult = this.B;
    const b = this.b.nominalValue;
    const s_B = this.s_B.nominalValue;

    objResult.nominalValue = b + 2 * s_B;
    objResult.inputValue = this.UnitConvert.showValue(objResult).inputValue;
  }


  foo_AreaWI() {
    const H = this.H.nominalValue;
    const B = this.B.nominalValue;
    const h = this.h.nominalValue;
    const b = this.b.nominalValue;

    let Area = H * B - h * b;
    this.Area.nominalValue = Area;
    this.UnitConvert.showValueResult(this.Area);

    let W = ((B * H * H * H) - (b * h * h * h)) / (6 * H);
    this.W.nominalValue = W;
    this.UnitConvert.showValueResult(this.W);

    let I = ((B * H * H * H) - (b * h * h * h)) / (12);
    this.I.nominalValue = I;
    this.UnitConvert.showValueResult(this.I);
  }

  Autofill(obj1: VariableUnitBuilder, obj2: VariableUnitBuilder) {
    obj2.nominalValue = obj1.nominalValue;
    obj2.inputValue = this.UnitConvert.showValue(obj2).inputValue;

    this.keyup_H(this.H);
    this.keyup_B(this.B);
  }

  fix_change1(obj: StatusFlagBuilder) {
    obj.status = !obj.status;  // ACTION

    // Bedingungen der Möglichkeiten
    if (obj != this.fixH) {
      this.fixH.status = false;
      this.fixH.STATUS = this.fixH.NameFalse;
    }
    if (obj != this.fixs_H) {
      this.fixs_H.status = false;
      this.fixs_H.STATUS = this.fixs_H.NameFalse;
    }
    if (obj != this.fixh) {
      this.fixh.status = false;
      this.fixh.STATUS = this.fixh.NameFalse;
    }

    //##########NAMENSUMASCHLAD AM ENDE###############
    if (obj.status === true) {
      obj.STATUS = obj.NameTrue;
    } else {
      obj.STATUS = obj.NameFalse;
    }
  }

  fix_change2(obj: StatusFlagBuilder) {
    obj.status = !obj.status;  // ACTION

    // Bedingungen der Möglichkeiten
    if (obj != this.fixB) {
      this.fixB.status = false;
      this.fixB.STATUS = this.fixB.NameFalse;
    }
    if (obj != this.fixs_B) {
      this.fixs_B.status = false;
      this.fixs_B.STATUS = this.fixs_B.NameFalse;
    }
    if (obj != this.fixb) {
      this.fixb.status = false;
      this.fixb.STATUS = this.fixb.NameFalse;
    }

    //##########NAMENSUMASCHLAD AM ENDE###############
    if (obj.status === true) {
      obj.STATUS = obj.NameTrue;
    } else {
      obj.STATUS = obj.NameFalse;
    }
  }
}
