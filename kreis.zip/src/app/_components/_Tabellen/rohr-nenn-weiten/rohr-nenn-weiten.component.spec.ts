import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {RohrNennWeitenComponent} from './rohr-nenn-weiten.component';

describe('RohrNennWeitenComponent', () => {
  let component: RohrNennWeitenComponent;
  let fixture: ComponentFixture<RohrNennWeitenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RohrNennWeitenComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RohrNennWeitenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
