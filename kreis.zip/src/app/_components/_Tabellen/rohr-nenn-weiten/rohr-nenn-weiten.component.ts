import {Component} from '@angular/core';
import {Sort} from '@angular/material/sort';

export interface Rohrgroesse {

  Size: string;
  ASME: string;
  DN: string;
  DIA: string;
  Inner: string;
}


@Component({
  selector: 'jg-rohr-nenn-weiten',
  templateUrl: './rohr-nenn-weiten.component.html',
  styleUrls: ['./rohr-nenn-weiten.component.sass']
})
export class RohrNennWeitenComponent {

  public visible: boolean = false;


  RohrGroessen: Rohrgroesse[] = [

    {Size: '1/2\'', ASME: '21.', DN: '15', DIA: '21.3', Inner: ' 12.3'},
    {Size: '3/4\'', ASME: '26.7', DN: '20', DIA: '26.9', Inner: '17.9'},
    {Size: '1\'', ASME: '33.4', DN: '25', DIA: '33.7', Inner: '24.7'},
    {Size: '1 1/4\'', ASME: '42.2', DN: '32', DIA: '42.4', Inner: '33.4'},
    {Size: '1 1/2\'', ASME: '48.3', DN: '40', DIA: '48.3', Inner: '39.3'},
    {Size: '2\'', ASME: '60.3', DN: '50', DIA: '60.3', Inner: '51.3'},
    {Size: '2 1/2\'', ASME: '73.0', DN: '65', DIA: '76.1', Inner: '67.1'},
    {Size: '3\'', ASME: '88.8', DN: '80', DIA: '88.9', Inner: '79.9'},
    {Size: '3 1/2\'', ASME: '101.6', DN: '90', DIA: '101.6', Inner: '92.6'},
    {Size: '4\'', ASME: '114.3', DN: '100', DIA: '114.3', Inner: '105.3'},
    {Size: '5\'', ASME: '141.3', DN: '125', DIA: '139.7', Inner: '130.7'},
    {Size: '6\'', ASME: '168.3', DN: '150', DIA: '168.3', Inner: '159.3'},
    {Size: '8\'', ASME: '219.1', DN: '200', DIA: '219.1', Inner: '210.1'},
    {Size: '10\'', ASME: '273.0', DN: '250', DIA: '273.0', Inner: '264.0'},
    {Size: '12\'', ASME: '323.8', DN: '300', DIA: '323.9', Inner: '314.9'},
    {Size: '14\'', ASME: '355', DN: '350', DIA: '355.6', Inner: '346.6'},
    {Size: '16\'', ASME: '406.4', DN: '400', DIA: '406.4', Inner: '397.4'},
    {Size: '18\'', ASME: '457.0', DN: '450', DIA: '457.0', Inner: '448.0'},
    {Size: '20\'', ASME: '508.0', DN: '500', DIA: '508.0', Inner: '499.0'},
    {Size: '22\'', ASME: '559.0', DN: '550', DIA: '559.0', Inner: '550.0'},
    {Size: '24\'', ASME: '610.0', DN: '600', DIA: '610.0', Inner: '601.0'}


  ];


//columnsToDisplay = ['Size', 'ASME', 'DN', 'DIA', 'Inner'];


  Size: string;
  ASME: string;
  DN: string;
  DIA: string;
  Inner: string;

  sortedData: Rohrgroesse[];

  constructor() {
    this.sortedData = this.RohrGroessen.slice();
  }

  sortData(sort: Sort) {
    const data = this.RohrGroessen.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {


        case 'Size':
          return compare(a.Size, b.Size, isAsc);
        case 'ASME':
          return compare(a.ASME, b.ASME, isAsc);
        case 'DN':
          return compare(a.DN, b.DN, isAsc);
        case 'Inner':
          return compare(a.Inner, b.Inner, isAsc);
        case 'DIA':
          return compare(a.DIA, b.DIA, isAsc);


      }
    });
  }
}

function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}


