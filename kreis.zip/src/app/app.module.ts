import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AppRoutingModule} from './app-routing.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {InputRestrictionDirective} from './_directives/input-restriction.directive';

import {AppComponent} from './app.component';
import {RechteckComponent} from './_components/_GeometrischeFormen/rechteck/rechteck.component';
import {KreisComponent} from './_components/_GeometrischeFormen/kreis/kreis.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {RohrNennWeitenComponent} from './_components/_Tabellen/rohr-nenn-weiten/rohr-nenn-weiten.component';

@NgModule({
  declarations: [
    AppComponent,
    InputRestrictionDirective,
     RechteckComponent,
    KreisComponent,
    RohrNennWeitenComponent,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
